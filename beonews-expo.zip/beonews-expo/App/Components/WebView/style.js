/** @format */

import { StyleSheet } from 'react-native'

export default StyleSheet.create({
  html: {
    marginLeft: 12,
    marginRight: 12,
    flex: 1,
  },
})
