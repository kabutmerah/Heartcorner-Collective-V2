import * as Expo from 'expo';
const { Font, Components, WebBrowser, FacebookAds, Lottie, LinearGradient, AdSettings, Google, Facebook, ImagePicker, Permissions } = Expo
export { Font, Components, WebBrowser, LinearGradient, FacebookAds, AdSettings, Google, Facebook, ImagePicker, Permissions };
export default Expo;
