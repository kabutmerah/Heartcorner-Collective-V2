// TODO(brentvatne): implement this plis
// export default function(fontNames) {
//   let result = {};
//
//   fontNames.forEach(fontName => {
//   });
//
//   return result;
// }
